import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { StudentsComponent } from './students/students.component';
import { StudentComponent } from './students/student/student.component';
import { StudentListComponent } from './students/student-list/student-list.component';
import { LecturersComponent } from './lecturers/lecturers.component';
import { LecturerComponent } from './lecturers/lecturer/lecturer.component';
import { LecturerListComponent } from './lecturers/lecturer-list/lecturer-list.component';
import { CoursesComponent } from './courses/courses.component';
import { CourseComponent } from './courses/course/course.component';
import { CourseListComponent } from './courses/course-list/course-list.component';
import { EnrollmentsComponent } from './enrollments/enrollments.component';
import { EnrollmentComponent } from './enrollments/enrollment/enrollment.component';
import { EnrollmentListComponent } from './enrollments/enrollment-list/enrollment-list.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    StudentsComponent,
    StudentComponent,
    StudentListComponent,
    LecturersComponent,
    LecturerComponent,
    LecturerListComponent,
    CoursesComponent,
    CourseComponent,
    CourseListComponent,
    EnrollmentsComponent,
    EnrollmentComponent,
    EnrollmentListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

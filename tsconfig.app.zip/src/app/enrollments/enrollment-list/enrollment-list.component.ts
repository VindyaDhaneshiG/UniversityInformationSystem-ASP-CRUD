import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-enrollment-list',
  templateUrl: './enrollment-list.component.html',
  styleUrls: ['./enrollment-list.component.css']
})
export class EnrollmentListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lecturer-list',
  templateUrl: './lecturer-list.component.html',
  styleUrls: ['./lecturer-list.component.css']
})
export class LecturerListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

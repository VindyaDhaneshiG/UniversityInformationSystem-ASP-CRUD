export class Lecturer {
}

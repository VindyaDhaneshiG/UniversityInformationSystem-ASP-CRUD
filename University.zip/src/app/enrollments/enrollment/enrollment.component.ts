import { Component, OnInit } from '@angular/core';
import { EnrollService } from 'src/app/shared/enroll.service';
import { NgForm } from '@angular/forms';
// import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-enrollment',
  templateUrl: './enrollment.component.html',
  styleUrls: ['./enrollment.component.css']
})
export class EnrollmentComponent implements OnInit {

  constructor(private service : EnrollService) { }
// ,private toster: ToastrService
  ngOnInit() {
  }
  resetForm(form? : NgForm){
    if(form != null)
       form.resetForm();
       this.service.formData={
        EnrollmentID: null,
        Description:'',
        Date:'',
        Fee: 2000,
        User:''
       }
       }
       onSubmit(form : NgForm) {
        if(form.value.EnrollmentID==null)
        this.insertRecord(form);
        else
        this.updateRecord(form);
      }
      searchRecord(id:number)
      {
       
      }
      insertRecord(form : NgForm){
       this.service.postEnroll(form.value).subscribe(res=> {
      // this.toster.success('Inserted Sucessfully','EMP Register')
      this.resetForm(form);
      this.service.refreshList();
       });
      }
      
      updateRecord(form:NgForm){
        this.service.putEnroll(form.value).subscribe(res=> {
          // this.toster.warning('Updated Sucessfully','EMP Register')
          this.resetForm(form);
          this.service.refreshList();
           });
      
      }
}

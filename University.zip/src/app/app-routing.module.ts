import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StudentComponent } from './students/student/student.component';
import { LecturerComponent } from 'src/app/lecturers/lecturer/lecturer.component';
import { CourseComponent } from 'src/app/courses/course/course.component';
import { EnrollmentComponent } from 'src/app/enrollments/enrollment/enrollment.component';
import { HomeComponent } from 'src/app/home/home.component';
import { StudentsComponent } from './students/students.component';
import { LecturersComponent } from './lecturers/lecturers.component';
import { CoursesComponent } from './courses/courses.component';
import { EnrollmentsComponent } from './enrollments/enrollments.component';

const routes: Routes = [{ path: 'home', component: HomeComponent },{ path: 'students', component: StudentsComponent },
{ path: 'lecturers',      component: LecturersComponent},{ path: 'courses', component: CoursesComponent },
{ path: 'enrollments',component: EnrollmentsComponent },{ path: '**', component: HomeComponent }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents=[HomeComponent, StudentsComponent,LecturersComponent,CoursesComponent,EnrollmentsComponent]
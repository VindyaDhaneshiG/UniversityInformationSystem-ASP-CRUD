import { Component, OnInit } from '@angular/core';
import { StudentService } from 'src/app/shared/student.service';
import { Student } from 'src/app/shared/student.model';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.css']
})
export class StudentListComponent implements OnInit {
  alldatas: object;
  stu:Student;
  constructor(private service :StudentService) { }
 // ,private toster: ToastrService
  ngOnInit() {
    // this.service.refreshList();
      this.service.getStudent().subscribe(res=> {
      this.alldatas = res;
       });
       this.service.refreshList();
  }
  resetForm(form?: NgForm) {
    if (form != null)
      form.resetForm();
    this.service.formData = {
      StudentID: null,
      FullName: '',
      Gender: '',
      Mobile: '',
      Email: ''
    }
  }

  populateForm(stu:Student){
    this.service.formData = Object.assign({},stu);
    // this.alldatas = Object.assign({},stu);
    // console.log(stu);
 }

 onDelete(id:number)
 {
   if(confirm("Are you sure to delete this record?")){
   this.service.deleteStudent(id).subscribe(res=>{
     this.service.refreshList();

      // this.toster.warning('Deleted Sucessfully','EMP Register')
   });}
 }
//  updateRecord(form: NgForm) {
//   this.service.putStudent(form.value).subscribe(res => {
//     // this.toastr.info('Updated successfully', 'Stu. Register');
//     this.resetForm(form);
//     this.service.refreshList();
//   });
  
//  EditTableRow(rowID){
// console.log(rowID);
// return rowID;
//  }
//  }

populateForm2(stu: Student) {
  this.service.formData = Object.assign({}, stu);
  console.log(this.service.formData);
  //return stu;
  //this.service.editStudentRow(stu);
  // this.service.formData = Object.assign({}, stu);
}
updateStudent(form : NgForm) {
 
  this.service.putStudent(form.value).subscribe(res => {
    // this.toastr.info('Updated successfully', 'EMP. Register');
    this.resetForm(form);
    this.service.refreshList();
  });
  
}

}


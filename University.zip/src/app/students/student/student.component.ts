import { Component, OnInit, Output } from '@angular/core';
import { StudentService } from 'src/app/shared/student.service';
import { NgForm } from '@angular/forms';
import { Student } from '../../shared/student.model';
import { StudentListComponent} from 'src/app/students/student-list/student-list.component';
// import { ToastrService } from 'ngx-toastr';
import { Routes, RouterModule } from '@angular/router';
import { AppRoutingModule,routingComponents } from 'src/app/app-routing.module';
import { EventEmitter } from 'events';
@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {
  constructor(private service : StudentService) { }
   // ,private toster: ToastrService
   alldatas: object;
  ngOnInit() {
    //console.log(this.service.formData);
    //console.log(this.stlist);
    //this.stlist.EditTableRow().;
    // this.service.refreshList();
    this.service.getStudent().subscribe(res=> {
      this.alldatas = res;
       });

  }

  resetForm(form? : NgForm){
    if(form != null)
       form.resetForm();
       this.service.formData = {
        StudentID: 0,
        FullName:'',
        Gender:'',
        Mobile : '',
        Email:''
       }
       }
       

       onSubmit(form : NgForm) {
        // if(form.value.StudentID==0)
        this.insertRecord(form);
        this.service.refreshList();
        // this.router.navigateByUrl('/RefrshComponent', {skipLocationChange: true}).then(()=>
        // this.router.navigate(["/enrollments"])); 
        // else
        // this.updateRecord(form);
      }
      insertRecord(form : NgForm){
       this.service.postStudent(form.value).subscribe(res=> {
      // this.toster.success('Inserted Sucessfully','Student Register')
      this.resetForm(form);
      this.service.refreshList();
       });
      }
      
      updateRecord(form:NgForm){
        this.service.putStudent(form.value).subscribe(res=> {
          // this.toster.warning('Updated Sucessfully','EMP Register')
          this.resetForm(form);
         this.service.refreshList();
           });
      
      }

}

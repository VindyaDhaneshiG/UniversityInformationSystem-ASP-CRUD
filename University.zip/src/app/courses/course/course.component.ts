import { Component, OnInit } from '@angular/core';
import { CourseService } from 'src/app/shared/course.service';
import { NgForm } from '@angular/forms';
// import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})
export class CourseComponent implements OnInit {
  // durations = [];
  constructor(private service : CourseService) { }
   // ,private toster: ToastrService
  ngOnInit() {
    this.resetForm();

  }
  // getDurations() {
  //   return [
  //     { id: '1', name: '2 Years' },
  //     { id: '2', name: '1 Years' },
  //     { id: '3', name: '9 Months' },
  //     { id: '4', name: '6 Months' },
  //     { id: '5', name: '3 Months' }
  //   ];
  // }
 
  resetForm(form? : NgForm){
    if(form != null)
       form.resetForm();
       this.service.formData = {
        CourseID: null,
        CourseName:'',
        Description:'',
        Duration : '',
        Commencement:''
       }
       }

       onSubmit(form : NgForm) {
        if(form.value.CourseID==null)
        this.insertRecord(form);
        else
        this.updateRecord(form);
        }

      insertRecord(form : NgForm){
        this.service.postCourse(form.value).subscribe(res=> {
       // this.toster.success('Inserted Sucessfully','EMP Register')
       this.resetForm(form);
       this.service.refreshList();
        });
       }
       
       updateRecord(form:NgForm){
        this.service.putCourse(form.value).subscribe(res=> {
        // this.toster.warning('Updated Sucessfully','EMP Register')
        this.resetForm(form);
        this.service.refreshList();
        });
       
       }
}

import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders } from "@angular/common/http";
import { Student } from './student.model';
import { StudentListComponent } from '../students/student-list/student-list.component';

const httpOptions={
  headers:new HttpHeaders({
    'Access-Control-Allow-Origin':'http://localhost:4200'
  })
}
@Injectable({
  providedIn: 'root'
})
export class StudentService {
  formData : Student;
  list : Student[];
  alldatas:Student;
  readonly rootURL="https://localhost:5001/api"
  constructor(private http:HttpClient) { }

postStudent( formData : Student){
  this.alldatas=formData;
  return this.http.post(this.rootURL+'/student',formData,httpOptions)
}

refreshList(){
this.http.get(this.rootURL+"/Student")
.toPromise()
.then(res => {this.list = res as Student[];
});
}

putStudent(formData:Student){
  this.alldatas=formData;
return this.http.put(this.rootURL+'/student/'+formData.StudentID,formData,httpOptions);
}
deleteStudent(id : number)
{
return this.http.delete(this.rootURL+'/student/'+id);
}
getStudent(){
  return this.http.get(this.rootURL+'/student',);
}
//get a particular student
GetStudent(id : number){

return this.http.get(this.rootURL+'/student/'+id);
}
// putCourse() {
//   return this.http.put(
//   this.rootURL + "/student/" + this.formData.StudentID,
//   this.formData
//   );
//   }

editStudentRow(data){
  console.log(data);
  return data;
}

}


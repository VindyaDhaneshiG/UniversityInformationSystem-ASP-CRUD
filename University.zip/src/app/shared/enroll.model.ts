export class Enroll {

        EnrollmentID:number;
        Description:string;
        Date:string;
        Fee:number;
        User:string;
}

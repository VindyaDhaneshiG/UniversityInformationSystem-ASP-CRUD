import { Enroll } from './enroll.model';

describe('Enroll', () => {
  it('should create an instance', () => {
    expect(new Enroll()).toBeTruthy();
  });
});

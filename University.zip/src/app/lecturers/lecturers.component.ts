import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lecturers',
  templateUrl: './lecturers.component.html',
  styleUrls: ['./lecturers.component.css']
})
export class LecturersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';
import { LecturerService } from 'src/app/shared/lecturer.service';
import { NgForm } from '@angular/forms';
import { Lecturer } from '../../shared/lecturer.model';
import { LecturerListComponent} from 'src/app/lecturers/lecturer-list/lecturer-list.component';
// import { ToastrService } from 'ngx-toastr';
// import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-lecturer',
  templateUrl: './lecturer.component.html',
  styleUrls: ['./lecturer.component.css']
})
export class LecturerComponent implements OnInit {

  constructor(private service : LecturerService) { }
  // ,private toster: ToastrService
  ngOnInit() {
  }
  resetForm(form? : NgForm){
    if(form != null)
       form.resetForm();
       this.service.formData = {
        LecturerID: null,
        FullName:'',
        Gender:'',
        Mobile : '',
        Email:''
       }
       }
       onSubmit(form : NgForm) {
        if(form.value.LecturerID==null)
        this.insertRecord(form);
        else
        this.updateRecord(form);
      }
      insertRecord(form : NgForm){
       this.service.postLecturer(form.value).subscribe(res=> {
      // this.toster.success('Inserted Sucessfully','EMP Register')
      this.resetForm(form);
      this.service.refreshList();
       });
      }
      
      updateRecord(form:NgForm){
        this.service.putLecturer(form.value).subscribe(res=> {
          // this.toster.warning('Updated Sucessfully','EMP Register')
          this.resetForm(form);
          this.service.refreshList();
           });
      
      }


}

import { Component, OnInit } from '@angular/core';
import { LecturerService } from 'src/app/shared/lecturer.service';
import { Lecturer } from 'src/app/shared/lecturer.model';

@Component({
  selector: 'app-lecturer-list',
  templateUrl: './lecturer-list.component.html',
  styleUrls: ['./lecturer-list.component.css']
})
export class LecturerListComponent implements OnInit {
  alldatas: object;
  constructor(private service :LecturerService) { }
  // ,private toster: ToastrService
  ngOnInit() {
    this.service.getLecturer().subscribe(res=> {
      this.alldatas = res;
      console.log(this.alldatas);
       });
    this.service.refreshList();
  }
  populateForm(lec:Lecturer){
    this.service.formData = Object.assign({},lec);

 }

 onDelete(id:number)
 {
   if(confirm("Are you sure to delete this record?")){
   this.service.deleteLecturer(id).subscribe(res=>{
     this.service.refreshList();
      // this.toster.warning('Deleted Sucessfully','EMP Register')
   });}
 }
}

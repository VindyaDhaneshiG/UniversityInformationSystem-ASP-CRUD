import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatelecturerComponent } from './updatelecturer.component';

describe('UpdatelecturerComponent', () => {
  let component: UpdatelecturerComponent;
  let fixture: ComponentFixture<UpdatelecturerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdatelecturerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdatelecturerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

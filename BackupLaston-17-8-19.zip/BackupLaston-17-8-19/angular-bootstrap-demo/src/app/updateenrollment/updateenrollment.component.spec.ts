import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateenrollmentComponent } from './updateenrollment.component';

describe('UpdateenrollmentComponent', () => {
  let component: UpdateenrollmentComponent;
  let fixture: ComponentFixture<UpdateenrollmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateenrollmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateenrollmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

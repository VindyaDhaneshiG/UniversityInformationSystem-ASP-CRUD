import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
// import { AuthGuard } from './auth.guard';
import { HomeComponent } from './home/home.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { StudentComponent } from './student/student.component';
import { StudentListComponent } from './student-list/student-list.component';
import { CourseComponent } from './course/course.component';
import { CourseListComponent } from './course-list/course-list.component';
import { LecturerComponent } from './lecturer/lecturer.component';
import { LecturerListComponent } from './lecturer-list/lecturer-list.component';
import { EnrollmentListComponent } from './enrollment-list/enrollment-list.component';
import { EnrollmentComponent } from './enrollment/enrollment.component';
import { LoginComponent } from './login/login.component';
// import { AdminComponent } from './admin/admin.component';

const routes: Routes = [
  {path:  "", pathMatch:  "full",redirectTo:  "home"},
  // { path: 'login', component: LoginComponent },
  {path: "home", component: HomeComponent},
  {path:"student",component:StudentComponent},
  {path:"student-list",component:StudentListComponent},
  {path:"lecturer",component:LecturerComponent},
  {path:"lecturer-list",component:LecturerListComponent},
  {path:"course", component:CourseComponent},
  {path:"course-list",component:CourseListComponent},
  {path:"enrollment",component:EnrollmentComponent},
  {path:"enrollment-list",component:EnrollmentListComponent},
  // { path: 'admin', component: AdminComponent, canActivate: [AuthGuard] }



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

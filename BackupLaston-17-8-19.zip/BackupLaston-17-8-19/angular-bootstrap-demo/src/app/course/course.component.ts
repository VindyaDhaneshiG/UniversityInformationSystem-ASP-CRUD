import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})
export class CourseComponent implements OnInit {
  course : {id,cname, cduration,coursetype,faculty,prerequisites} = {id :null, cname:" ", cduration :" ",coursetype:" ",faculty:" ",prerequisites:" "};

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {
  student : {id,fname, lname,dob,email,gender, address} = {id :null, fname:" ", lname :"",dob:"",email:"",gender:"", address:""};
  constructor(public dataService: StudentService) { }

  ngOnInit() {
  }
  createContact(){
    console.log(this.student);
    this.dataService.createStudent(this.student);
    this.student = {id :null, fname:" ", lname :"",dob:"",email:"",gender:"", address:""};
}
}

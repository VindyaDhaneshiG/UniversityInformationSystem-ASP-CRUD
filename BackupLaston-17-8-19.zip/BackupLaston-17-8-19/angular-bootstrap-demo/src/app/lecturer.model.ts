export class Lecturer {

LecturerID:number;
FirstName:string;
LastName:string;
DateofBirth:string;
DateofJoin:string;
ContactEmail:string;
Gender:string;
ContactAddress:string;
LecturerCategory:string;
LecturerContract:string;
LecturerQualification:string;

}

using System;  
using System.Collections.Generic;  
using System.ComponentModel.DataAnnotations;  
using System.Linq;  
using System.Threading.Tasks;  

namespace Swinburne_Uni_New.Models
{
    public class Enrollment
    {
      [Key]
    public int EnrollmentID {get;set;}
    
    public string EnrollmentDate{get;set;}
    public int StudentID {get;set;}
    public string StudentName{get;set;}
    public int CourseID {get;set;}
    public string CourseName{get;set;}
    public string EnrollmentStatus{get;set;}
    public int CourseFee{get;set;}
    public string Installments{get;set;}
    public int InstallmentPaymentAmount{get;set;}

    }
}
